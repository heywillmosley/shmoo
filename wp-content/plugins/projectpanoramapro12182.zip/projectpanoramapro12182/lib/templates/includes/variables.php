<?php

	global $psp_project_overview;	
	global $psp_project_milestones;
	global $psp_project_documents;
	global $psp_project_tasks; 
				
	$psp_project_overview->the_meta();
	$psp_project_milestones->the_meta();
	$psp_project_documents->the_meta();
	$psp_project_tasks->the_meta();
	
?>