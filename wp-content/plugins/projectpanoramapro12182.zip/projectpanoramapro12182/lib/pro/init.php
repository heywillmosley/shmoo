<?php

    // Pro specific functionality

    require_once('pro_shortcodes.php');

    add_action('init', 'psp_load_custom_fields');
    function psp_load_custom_fields() {
        // Load the custom fields
        include_once('fields.php');
    }


?>
