=== Project Panorama ===
Contributors: Ross Johnson
Tags: project, management, project management, basecamp, status, client, admin, intranet
Requires at least: 3.5.0
Tested up to: 3.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Keep clients happy by communicating project status and progress in a visual way. Project Panorama is a simple and effective alternative to basecamp and other project management software.

== Description ==

Project Status is a WordPress project management plugin designed to keep your clients and team in the loop. Each project can be configured to display overall project status, store documents, identify task and task completion, have phases and phase progress.

= Tested on =
* Mac Firefox 	:)
* Mac Safari 	:)
* Mac Chrome	:)
* PC Firefox	:)
* PC IE9/10/11	:)
* PC IE8 - Not great, but usable

= Website =
http://www.projectpanorama.com

= Documentation =
http://www.projectpanorama.com/docs

= Bug Submission and Forum Support =
http://www.projectpanorama.com/forums
http://www.projectpanorama.com/support


== Installation ==

1. Upload 'project-panorama' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the new menu item "Projects" and create your first project!
4. You can now visit and share the project with clients
5. Embed projects into pages and posts using the embed code [project_status id="<post_id>"] which can be found on the project listing page

== Upgrading == 

Upgrading from Project Panorama Lite? 

1. Disable Project Panorama Lite
2. Upload Project Panorama Pro
3. Activate Project Panorama Pro

All of your projects will exist. You may have to readd your documents to the new and improved document manager. 

== Shortcodes ==

== Frequently Asked Questions ==

= Q. I have a question =
A. Chances are, someone else has asked it. Check out the support forum at: 
http://www.projectpanorama.com/forums

= Q. I'm getting 404 errors on my projects or other plugins

First Try going to settings > permalinks and resaving your permalinks
If that doesn't work, there is probably another plugin thats conflicting with Panorama. You can try editing the /project-panorama/lib/data_model.php file and removing line 56 that says "flush_rewrite_rules();" - Then resave your permalinks.

= Q. Logging into a project redirects me to another page
  A. This happens when you have another plugin that alters standard login redirects, often a ticketing system or other "project management like" plugin. You will need to have the author of that plugin help you remove the global user redirect.

== Credit ==

Project Panorama is powered by Advanced Custom Fields and the Advanced Custom Field Repeater Addon. Advanced Custom Field Repeater Addon may not be removed, distributed or sold without purchase from Advanced Custom Fields (http://www.advancedcustomfields.com). 

== Changelog ==

= 1.2.1.8.2 =
* Added the ability to use your own template, simply create a folder called "panorama" in your theme directory and then copy /wp-content/plugins/panorama/lib/templates/single.php into it. You can then modify the file as you'd like
* Added project listing widget
* You can now use URLs for documents
* Added color customizations and an open css text box to the settings page

= 1.2.1.8.1 =
* Minor bug fix

= 1.2.1.8 =
* Adjusted project_list shortcode to only display projects viewing user has access to, this can be overwritten by adding an access="all" attribute
* Added two user roles, 'Project Owner' and 'Project Manager' - More information here http://www.projectpanorama.com/docs/permissions
* Project editing in the admin is now restricted by the access control settings, i.e. authors/editors/project owners can only edit projects assigned to them (admins and project managers can edit all projects)
* Fixed issue where auto-calculation wouldn't work if you only had one task

= 1.2.1.6 = 
* Added function to translate ACF fields

= 1.2.1.5 =
* Fixed output of "Fired" on plugin page
* Added [panorama_dashboard] shortcode
* Expanding and collapsing task lists
* Fixed issue where project list wouldn't output completed only projects
* Slightly redesigned interface

= 1.2.1.2 =
* Working translation and textdomain
* Added translations for French and Bulgarian - Thanks Gregory Further and Yassen Yotov!
* Move settings into the Project Panorama menu
* Added hooks into the template for future addons and easier styling adjustments
* Login form no longer trips security on WPEngine
* Fixed some misc bugs
* Adds dashboard widget

= 1.2.1 =
* Better translation and textdomain support
* Reworked shortcode system, now you can embed parts of projects, configure your project output and adjust what projects are listed
* Added "Project Type" custom taxonomy
* Added the ability to alter your project slug (from panorama to anything else)
* Added the ability to brand your projects
* Styling improvements and fixes
* Expanded WYSIWYG tools
* Support for WP 3.9

= 1.2 =
* Swapped out donut charts for Pizza Charts by Zurb (much nicer at all resoultions, better IE support)
* Added password protection
* Added user management / restrictions
* Check for duplicate post plugin before including
* Added option to noindex projects
* Minor styling tweaks
* Only load scripts and styles when a shortcode is used or on a project page

= 1.1.3 = 
Small Bug Fixes - Added icons to new shortcode buttons

= 1.0 = 
* Initial Release!