<?php


/************************************
* the code below is just a standard
* options page. Substitute with 
* your own.
*************************************/

function edd_panorama_license_menu() {
	add_submenu_page( 'edit.php?post_type=psp_projects','Project Panorama Settings', 'Settings', 'manage_options', 'panorama-license', 'edd_panorama_license_page' );
}
add_action('admin_menu', 'edd_panorama_license_menu');

function edd_panorama_license_page() {
	$license 	= get_option( 'edd_panorama_license_key' );
	$status 	= get_option( 'edd_panorama_license_status' );
	?>
	<div class="wrap">
		<h2><?php _e('Project Panorama License Options','psp_projects'); ?></h2>

        <?php if($_GET['settings-updated'] == 'true') {

            flush_rewrite_rules(); ?>

            <div class="updated">
                <p>The Project Panorama settings have been updated.</p>
            </div>

        <?php } ?>

		<form method="post" action="options.php">
		
			<?php settings_fields('edd_panorama_license'); ?>

        <?php if(PSP_PLUGIN_TYPE == 'professional'): ?>
        <table class="form-table">
				<tbody>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php _e('License Key','psp_projects'); ?>
						</th>
						<td>
							<input id="edd_panorama_license_key" name="edd_panorama_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license ); ?>" />
							<label class="description" for="edd_panorama_license_key"><?php _e('Enter your license key','psp_projects'); ?></label>
						</td>
					</tr>
					<?php if( false !== $license ) { ?>
						<tr valign="top">	
							<th scope="row" valign="top">
								<?php _e('Activate License','psp_projects'); ?>
							</th>
							<td>
								<?php if( $status !== false && $status == 'valid' ) { ?>
									<span style="color:green;" class="psp-activation-notice"><?php _e('Active','psp_projects'); ?></span>
									<?php wp_nonce_field( 'edd_panorama_nonce', 'edd_panorama_nonce' ); ?>
									<input type="submit" class="button-secondary" name="edd_license_deactivate" value="<?php _e('Deactivate License','psp_projects'); ?>"/>
								<?php } else { ?>
                                    <span style="color:red;" class="psp-activation-notice"><?php _e('Inactive','psp_projects'); ?></span>
									<?php wp_nonce_field( 'edd_panorama_nonce', 'edd_panorama_nonce' ); ?>
									<input type="submit" class="button-secondary" name="edd_license_activate" value="<?php _e('Activate License','psp_projects'); ?>"/>
								<?php } ?>
							</td>
						</tr>
					<?php } ?>
			</table>
			<?php endif; ?>

            <hr>


            <h2>Apperance</h2>


          	<table class="form-table">
          	    <tr>
						<th scope="row" valign="top">
							<label for="psp_slug"><?php _e('Project Slug','psp_projects'); ?></label>
						</th>
						<td>
							<input id="psp_slug" value="<?php echo get_option('psp_slug','panorama'); ?>" type="text" name="psp_slug">
						</td>
					</tr>
					<tr>
						<th scope="row" valign="top">
							<label for="psp_logo"><?php _e('Logo for Project Pages','psp_projects'); ?></label>
						</th>
						<td>
						    <input id="psp_logo" type="text" size="36" name="psp_logo" value="<?php echo get_option('psp_logo','http://'); ?>" />
						    <input id="psp_upload_image_button" class="button" type="button" value="Upload Image" />
						</td>
					</tr>
				</tbody>
			</table>

            <fieldset class="psp-fieldset">
                <legend>Header</legend>


            <table class="form-table psp-color-table">
                <tr>
                    <th scope="row" valign="top">
                        <label for="psp_header_background">Header Background</label>
                    </th>
                    <td>
                        <input id="psp_header_background" value="<?php echo get_option('psp_header_background'); ?>" name="psp_header_background" class="color-field" rel="2a3542">
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="psp_header_text">Header Text</label>
                    </th>
                    <td>
                        <input id="psp_header_text" value="<?php echo get_option('psp_header_text'); ?>" name="psp_header_text" class="color-field" rel="aaa">
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="psp_header_accent">Accent Text</label>
                    </th>
                    <td>
                        <input id="psp_header_accent" value="<?php echo get_option('psp_header_accent'); ?>" name="psp_header_accent" class="color-field" rel="aeb2b7">
                    </td>
                </tr>
                <tr>
                    <th scope="row" valign="top">
                        <label for="psp_menu_background">Menu Background</label>
                    </th>
                    <td>
                        <input id="psp_menu_background" value="<?php echo get_option('psp_menu_background'); ?>" name="psp_menu_background" class="color-field" rel="2a3542">
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="psp_menu_text">Menu Text</label>
                    </th>
                    <td>
                        <input id="psp_menu_text" value="<?php echo get_option('psp_menu_text'); ?>" name="psp_menu_text" class="color-field" rel="fff">
                    </td>
                </tr>
            </table>

            </fieldset>

            <fieldset class="psp-fieldset">
                <legend>Body</legend>

                <table class="form-table psp-color-table">
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_body_background">Body Background</label>
                        </th>
                        <td>
                            <input id="psp_body_background" value="<?php echo get_option('psp_body_background'); ?>" name="psp_body_background" class="color-field" rel="f1f2f7">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_body_heading">Body Heading</label>
                        </th>
                        <td>
                            <input id="psp_body_heading" value="<?php echo get_option('psp_body_heading'); ?>" name="psp_body_heading" class="color-field" rel="#999">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_body_background">Body Text</label>
                        </th>
                        <td>
                            <input id="psp_body_text" value="<?php echo get_option('psp_body_text'); ?>" name="psp_body_text" class="color-field" rel="333">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_body_link">Body Link</label>
                        </th>
                        <td>
                            <input id="psp_body_link" value="<?php echo get_option('psp_body_link'); ?>" name="psp_body_link" class="color-field" rel="000">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_footer_background">Footer Background</label>
                        </th>
                        <td>
                            <input id="psp_footer_background" value="<?php echo get_option('psp_footer_background'); ?>" name="psp_footer_background" class="color-field" rel="2a3542">
                        </td>
                    </tr>
                </table>

                <p><input type="button" class="psp-reset-colors button-secondary" value="Reset Colors to Default" name="psp-reset-colors"></p>


            </fieldset>

            <fieldset class="psp-fieldset">
                <legend>Custom Styling</legend>
                <table class="form-table">
                    <tr>
                        <th scope="row" valign="top">
                            <label for="psp_open_css">Custom CSS</label>
                        </th>
                        <td>
                            <textarea rows="10" cols="75" name="psp_open_css" id="psp_open_css"><?php echo get_option('psp_open_css'); ?></textarea>
                        </td>
                    </tr>
                </table>
            </fieldset>

            <?php do_action('psp_settings_page'); ?>

			<?php submit_button(); ?>
		
		</form>
	<?php
}

function edd_panorama_register_options() {
	// creates our settings in the options table
	register_setting('edd_panorama_license', 'edd_panorama_license_key', 'edd_sanitize_license');
	
	// Additional options
	add_option('psp_slug','panorama');
	add_option('psp_logo');
	add_option('psp_flush_rewrites');
    add_option('psp_rewrites_flushed');
	
	register_setting( 'edd_panorama_license', 'psp_slug' ); 
	register_setting( 'edd_panorama_license', 'psp_logo' ); 
	register_setting( 'edd_panorama_license', 'psp_flush_rewrites' );
    register_setting( 'edd_panorama_license', 'psp_rewrites_flushed' );

    // Color Styling

    // Header
    add_option('psp_header_background','#2a3542');
    add_option('psp_header_text','#aaa');
    add_option('psp_menu_background','#2a3542');
    add_option('psp_menu_text','#fff');
    add_option('psp_header_accent','#aeb2b7');

    // Body
    add_option('psp_body_background','#f1f2f7');
    add_option('psp_body_text','#333');
    add_option('psp_body_link','#000');
    add_option('psp_body_heading','#999');
    add_option('psp_footer_background','#2a3542');


    add_option('psp_open_css');

    // Register Settings
    register_setting( 'edd_panorama_license', 'psp_header_background' );
    register_setting( 'edd_panorama_license', 'psp_header_text');
    register_setting( 'edd_panorama_license', 'psp_menu_background');
    register_setting( 'edd_panorama_license', 'psp_menu_text');
    register_setting( 'edd_panorama_license', 'psp_header_accent');

    register_setting('edd_panorama_license','psp_body_background');
    register_setting('edd_panorama_license','psp_body_text');
    register_setting('edd_panorama_license','psp_body_link');
    register_setting('edd_panorama_license','psp_body_heading');
    register_setting('edd_panorama_license','psp_footer_background');

    register_setting( 'edd_panorama_license', 'psp_open_css');

} 	

add_action('admin_init', 'edd_panorama_register_options');

function edd_sanitize_license( $new ) {
	$old = get_option( 'edd_panorama_license_key' );
	if( $old && $old != $new ) {
		delete_option( 'edd_panorama_license_status' ); // new license has been entered, so must reactivate
	}
	return $new;
}

add_action('admin_init', 'psp_check_if_rewrites_flushed');
function psp_check_if_rewrites_flushed() {

    $flushed = get_option('psp_rewrites_flushed');

    if($flush != 'yes') {
        flush_rewrite_rules();
        update_option('psp_rewrites_flushed','yes');
    }

}



/************************************
* this illustrates how to activate 
* a license key
*************************************/

function edd_panorama_activate_license() {
		
	// listen for our activate button to be clicked
	if( isset( $_POST['edd_license_activate'] ) ) {
				
		// run a quick security check 
	 	if( ! check_admin_referer( 'edd_panorama_nonce', 'edd_panorama_nonce' ) ) 	
			return; // get out if we didn't click the Activate button

		// retrieve the license from the database
		$license = trim( get_option( 'edd_panorama_license_key' ) );
			

		// data to send in our API request
		$api_params = array( 
			'edd_action'=> 'activate_license', 
			'license' 	=> $license, 
			'item_name' => urlencode( EDD_PROJECT_PANORAMA ) // the name of our product in EDD
		);
		
		// Call the custom API.
		$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) )
			return false;

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );
		
		// $license_data->license will be either "active" or "inactive"

		update_option( 'edd_panorama_license_status', $license_data->license );

	}
	

		
}
add_action('admin_init', 'edd_panorama_activate_license',0);


/***********************************************
* Illustrates how to deactivate a license key.
* This will descrease the site count
***********************************************/

function edd_panorama_deactivate_license() {

	// listen for our activate button to be clicked
	if( isset( $_POST['edd_license_deactivate'] ) ) {

		// run a quick security check 
	 	if( ! check_admin_referer( 'edd_panorama_nonce', 'edd_panorama_nonce' ) ) 	
			return; // get out if we didn't click the Activate button

		// retrieve the license from the database
		$license = trim( get_option( 'edd_panorama_license_key' ) );
			

		// data to send in our API request
		$api_params = array( 
			'edd_action'=> 'deactivate_license', 
			'license' 	=> $license, 
			'item_name' => urlencode( EDD_PROJECT_PANORAMA ) // the name of our product in EDD
		);
		
		// Call the custom API.
		$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) )
			return false;

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );
		
		// $license_data->license will be either "deactivated" or "failed"
		if( $license_data->license == 'deactivated' )
			delete_option( 'edd_panorama_license_status' );

	}
}
add_action('admin_init', 'edd_panorama_deactivate_license');


/************************************
* this illustrates how to check if 
* a license key is still valid
* the updater does this for you,
* so this is only needed if you
* want to do something custom
*************************************/

function edd_panorama_check_license() {

	global $wp_version;

	$license = trim( get_option( 'edd_panorama_license_key' ) );
		
	$api_params = array( 
		'edd_action' => 'check_license', 
		'license' => $license, 
		'item_name' => urlencode( EDD_PROJECT_PANORAMA ) 
	);

	// Call the custom API.
	$response = wp_remote_get( add_query_arg( $api_params, PROJECT_PANORAMA_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );
	
	if ( is_wp_error( $response ) )
		return false;

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	if( $license_data->license == 'valid' ) {
		echo 'valid'; exit;
		// this license is still valid
	} else {
		echo 'invalid'; exit;
		// this license is no longer valid
	}
}
